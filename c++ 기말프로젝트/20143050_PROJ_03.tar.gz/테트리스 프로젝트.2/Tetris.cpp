#include"Tetris.h"

Tetris::Tetris(){
initscr();
start_color();
cbreak();
refresh();
infoPane_ = new InfoPane(1,1,25,5);
helpPane_ = new HelpPane(1,6,25,12);
nextPane_ = new NextPane(1,18,25,5);
boardPane_ = new BoardPane(30,0,22,22);
statPane_ = new StatPane(60,3,20,20);
block_[0]=new O_block();
block_[1]=new L_block();
block_[2]=new J_block();
block_[3]=new S_block();
block_[4]=new Z_block();
block_[5]=new T_block();
block_[6]=new I_block();
temp_block[0]=new O_block();
temp_block[1]=new L_block();
temp_block[2]=new J_block();
temp_block[3]=new S_block();
temp_block[4]=new Z_block();
temp_block[5]=new T_block();
temp_block[6]=new I_block();
x=0;
y=3;
score=0;
rotateNum = 0;
flag=0;
for(int i=0;i<20;++i)
  for(int j=0;j<10;++j)
    board[i][j]=0;
}

Tetris::~Tetris()
{
delete infoPane_;
delete helpPane_;
delete nextPane_;
delete boardPane_;
delete statPane_;
for(int i=0;i<7;++i)
delete block_[i];
endwin();
}

void Tetris::updateScreen(){
keypad(stdscr, TRUE);           /* We get F1, F2 etc..          */
helpPane_->draw();
boardPane_->draw();
nextpaneprint();
printScoreBoard();
printGameBoard();
}
void Tetris::printGameBoard(){((BoardPane*)boardPane_)->draw2(x,y,board,block_[randNum]);}
void Tetris::printScoreBoard(){((StatPane*)statPane_)->draw2(score);}
void Tetris::printusername(char user_name[]){((InfoPane*)infoPane_)->draw2(user_name);}
void Tetris::nextpaneprint(){  ((NextPane*)nextPane_)->draw2(0,4,temp_block[randNum2]);}
int Tetris::get_seed(int seed_,int flag_)
{
  flag=flag_;
  if(!flag)
  {
    srand((unsigned)time(NULL));
  }
  else
  {
    srand(seed_);
  }
  randNum=rand()%7;
  randNum2=rand()%7;
}

int Tetris::moveBlock(int dir)
{
	switch(dir)
	{
	case KEY_DOWN:
		if (!isCollision(1,0))
			x++;
    	break;
	case KEY_LEFT:
		if (!isCollision(0,-1))
			y--;
		break;
	case KEY_RIGHT:
		if (!isCollision(0,1))
			y++;
		break;
  case KEY_UP:
    {
      rotateNum++;
      block_[randNum]->rotate_block(rotateNum);
      if(isCollision(0,0))
      {
        rotateNum--;
        block_[randNum]->rotate_block(rotateNum);
      }
    }
    break;
	case 32:
		while (!isCollision(1,0))
			x++;
		break;
	}

	if (isCollision(1,0))
  {

		for (int i = 0; i <  4; i++)
		{
      	for (int j = 0; j < 4; j++)
			{
				if(block_[randNum]-> get_shape(i,j) != 0){
					board[x+i][y+j] = block_[randNum]-> get_shape(i,j);
				}
			}
		}

	  for (int j = 0; j < 10; j++)
		{
			if (board[0][j] != 0)
			{
				printGameBoard();
				return 1;
			}
		}

	   x = 0, y = 3;

		if (isCollision(1,0))
		{
			printGameBoard();
			return 1;
		}
    randNum=randNum2;
    randNum2=rand()%7;
    if(!isCollision(0,0))
    {
      rotateNum=0;
      block_[randNum]->rotate_block(rotateNum);
    }
	}

	checkLine();//밑에 쌓이면 제거해주기
	printScoreBoard();//점수 최신화
	printGameBoard();//화면 출력
  nextpaneprint();
	return 0;
}
void Tetris::checkLine()
{
	int i, j, k;
	int check;

	i = 19;

	while (i >= 0)
	{
		check = 1;

		for (j = 0; j<10; j++)
		{
			if (board[i][j] == 0)
			{
				check = 0;
				break;
			}
		}

		if (check == 1)
		{
			score += 1;
			for (k = i - 1; k >= 0; k--)
			{
				for (j = 0; j<10; j++)
				{
					board[k + 1][j] = board[k][j];
				}
			}
			for (j = 0; j<10; j++)
			{
				board[0][j] = 0;
			}

			continue;
		}

		i--;
	}

}

bool Tetris::isCollision(int a,int b)
{

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if(block_[randNum] -> get_shape(i, j) != 0 && ((x + a + i) < 0 || (x + a + i) > 19|| (y + b + j) < 0 || (y + b + j) > 9 || board[x + a + i][y + b + j] != 0))
			{
				return true;
			}
		}
	}
	return false;
}
