#include"Tetris.h"
#include<ncurses.h>
#include<fstream>
#include<iostream>
#include"kbhit.h"
int main(int argc, char* argv[])
{
	std::ifstream inStream;

	char user_name[20];
	if(argc<2)
	{
			std::cout << "테트리스 게임을 시작합니다." << std::endl;
			std::cout << "사용자의 이름을 입력하세요." << std::endl;
			std::cout << "이름: ";
			std::cin >> user_name;
	}
	Tetris game;
	int key=0, state = 0;
	int seed=0;
	if (argc < 2)
	{
		game.printusername(user_name);
		game.get_seed(seed,0);
		game.updateScreen();
		while (state == 0)
		{
		  halfdelay(15);
			int key= getch();
		  if(kbhit()){
				game.moveBlock(KEY_DOWN);
			}
			raw();
			cbreak();
      keypad(stdscr, TRUE);           /* We get F1, F2 etc..          */
      noecho();
      curs_set(0);

			if (key == 'q')
      	break;
			state = game.moveBlock(key);
		}
	}
	else
	{
		inStream.open(argv[1]);
		if (!inStream.fail())
		{
			inStream>>user_name>>seed;
			game.printusername(user_name);
			game.get_seed(seed,1);
			game.updateScreen();
			while (1)
			{
				char ch;
	      curs_set(0);
				inStream >> ch;
				if (inStream.eof()) break;
				if (ch == 'q') break;
				usleep(400000);
				switch (ch)
				{
				case 'l':
					game.moveBlock(KEY_LEFT);
					break;
				case 'r':
					game.moveBlock(KEY_RIGHT);
					break;
				case 'g':
					game.moveBlock(KEY_DOWN);
					break;
				case 't':
					game.moveBlock(KEY_UP);
					break;
				case 'd':
					game.moveBlock(32);
					break;
				}
			}
		}
	}

	getch();
	return 0;
}
