#include<iostream>
#include<string>
#include<cstdlib>
#include<ctime>
#include"Pane.h"
#include"InfoPane.h"
#include"BoardPane.h"
#include"StatPane.h"
#include"HelpPane.h"
#include"NextPane.h"
#include"Block.h"
#include"O_block.h"
#include"I_block.h"
#include"L_block.h"
#include"J_block.h"
#include"S_block.h"
#include"Z_block.h"
#include"T_block.h"

class Tetris {
Pane *infoPane_, *helpPane_, *nextPane_, *boardPane_, *statPane_;
Block* block_[7];
Block* temp_block[7];
public:
Tetris();
~Tetris();
void updateScreen();
void printGameBoard();
void printScoreBoard();
void printusername(char user_name[]);
void nextpaneprint();
int moveBlock(int dir);
int get_seed(int seed,int flag);
void checkLine();
bool isCollision(int a, int b);
private:
  int x,y;
  int board[20][10];
  int score;
  int rotateNum;
  int randNum;
  int randNum2;
  int flag;
};
