#ifndef T_bLOCK
#define T_bLOCK
#include"Block.h"
class T_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	T_block();
	virtual void rotate_block(int rotate_num);
	~T_block();
};
#endif
