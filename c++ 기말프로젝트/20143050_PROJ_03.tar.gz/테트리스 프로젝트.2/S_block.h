#ifndef S_bLOCK
#define S_bLOCK
#include"Block.h"
class S_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	S_block();
	virtual void rotate_block(int rotate_num);
	~S_block();
};
#endif
