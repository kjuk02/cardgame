#ifndef L_bLOCK
#define L_bLOCK
#include"Block.h"
class L_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	L_block();
	virtual void rotate_block(int rotate_num);
	~L_block();
};
#endif
