#include"StatPane.h"

StatPane::StatPane(int x, int y, int w, int h) : Pane(x,y,w,h){}

void StatPane::draw(){
init_pair(6, COLOR_RED, COLOR_BLACK);
wattron(win_, COLOR_PAIR(6));
box(win_, 0, 0);
mvwprintw(win_, 0, 5, "STATISTICS");
wattroff(win_, COLOR_PAIR(6));
wrefresh(win_);
}
void StatPane::draw2(int score){
init_pair(6, COLOR_RED, COLOR_BLACK);
init_pair(23,COLOR_RED,COLOR_BLACK);
wattron(win_, COLOR_PAIR(6));
box(win_, 0, 0);
mvwprintw(win_, 0, 5, "STATISTICS");
wattroff(win_, COLOR_PAIR(6));
wattron(win_, COLOR_PAIR(23));
mvwprintw(win_,2,1,"NOW SCORE: ");
mvwprintw(win_,2,12,"%d ", score);
wattroff(win_, COLOR_PAIR(23));
wrefresh(win_);
}
