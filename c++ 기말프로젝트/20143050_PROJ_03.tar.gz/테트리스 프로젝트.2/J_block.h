#ifndef J_bLOCK
#define J_bLOCK
#include"Block.h"
class J_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	J_block();
	virtual void rotate_block(int rotate_num);
	~J_block();
};
#endif
