#include"I_block.h"

I_block::I_block() : Block()
{
	Block_init();
	setBlock(0,1,7);
	setBlock(1,1,7);
	setBlock(2,1,7);
	setBlock(3,1,7);
}
I_block::~I_block(){};

void I_block::rotate_block(int rotate_num)
{
	Block_init();
	if(rotate_num%2==0)
	{
		setBlock(0,1,7);
	  setBlock(1,1,7);
	  setBlock(2,1,7);
	  setBlock(3,1,7);
	}
	else
	{
		setBlock(1,0,7);
	  setBlock(1,1,7);
	  setBlock(1,2,7);
	  setBlock(1,3,7);
	}
}
