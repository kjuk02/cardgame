#include"Pane.h"

class StatPane : public Pane {
public:
StatPane(int x, int y, int w, int h);
void draw();
void draw2(int score);
};
