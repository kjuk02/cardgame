#include"Block.h"
Block::Block()
{
  for(int i = 0 ; i < width;i++)
    for(int j = 0; j <width; j++)
      board[i][j] = 0;
}
void Block::Block_init()
{
  for(int i = 0 ; i < width;i++)
    for(int j = 0; j <width; j++)
      board[i][j] = 0;
}
void Block::setBlock(int x,int y,int value)
{
  if(x < 0 || y < 0 || x >= width || y>= width)	return;

  board[x][y] = value;
}
int Block::get_shape(const int x,const int y)//이거는 블록의 형태에따라 1의 값을 구하는것
{
  if(x < 0 || y < 0 || x >= width || y>= width);
  return board[x][y];
}
void Block::rotate_block(int rotate_num){}
Block::~Block(){}
