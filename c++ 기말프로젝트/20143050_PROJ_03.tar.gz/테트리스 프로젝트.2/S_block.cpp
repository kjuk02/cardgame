#include"S_block.h"

S_block::S_block() : Block()
{
	Block_init();
	setBlock(0,1,4);
	setBlock(1,1,4);
	setBlock(1,2,4);
	setBlock(2,2,4);
}
S_block::~S_block(){};

void S_block::rotate_block(int rotate_num)
{
	Block_init();
	if(rotate_num%2==0)
	{
		setBlock(0,1,4);
		setBlock(1,1,4);
		setBlock(1,2,4);
		setBlock(2,2,4);
	}
	else
	{
		setBlock(0,1,4);
		setBlock(0,2,4);
		setBlock(1,0,4);
		setBlock(1,1,4);
	}
}
