#ifndef Z_bLOCK
#define Z_bLOCK
#include"Block.h"
class Z_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	Z_block();
	virtual void rotate_block(int rotate_num);
	~Z_block();
};
#endif
