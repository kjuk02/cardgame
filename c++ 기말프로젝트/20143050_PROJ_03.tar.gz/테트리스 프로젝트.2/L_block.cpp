#include"L_block.h"

L_block::L_block() : Block()
{
	Block_init();
	setBlock(0,1,2);
	setBlock(1,1,2);
	setBlock(2,1,2);
	setBlock(2,2,2);
}
L_block::~L_block(){};
void L_block::rotate_block(int rotate_num)
{
	Block_init();

	if(rotate_num%4==0)
	{
		setBlock(0,1,2);
		setBlock(1,1,2);
		setBlock(2,1,2);
		setBlock(2,2,2);
	}
	else if(rotate_num%4==1)
	{
		setBlock(0,2,2);
		setBlock(1,0,2);
		setBlock(1,1,2);
		setBlock(1,2,2);
	}
	else if(rotate_num%4==2)
	{
		setBlock(0,0,2);
		setBlock(0,1,2);
		setBlock(1,1,2);
		setBlock(2,1,2);
	}
	else
	{
		setBlock(1,0,2);
		setBlock(1,1,2);
		setBlock(1,2,2);
		setBlock(2,0,2);
	}
}
