#include"Pane.h"
#include<ncurses.h>
#include<string>
class InfoPane : public Pane {
public:
InfoPane(int x, int y, int w, int h);
void draw();
void draw2(char user_name[]);
};
