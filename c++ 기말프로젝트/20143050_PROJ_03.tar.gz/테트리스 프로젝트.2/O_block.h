#ifndef O_bLOCK
#define O_bLOCK
#include"Block.h"
class O_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	O_block();
	virtual void rotate_block(int rotate_num){};
	~O_block();
};
#endif
