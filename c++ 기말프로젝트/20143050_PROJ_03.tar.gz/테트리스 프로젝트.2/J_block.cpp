#include"J_block.h"

J_block::J_block() : Block()
{
	Block_init();
	setBlock(0,1,3);
	setBlock(1,1,3);
	setBlock(2,0,3);
	setBlock(2,1,3);
}
J_block::~J_block(){};
void J_block::rotate_block(int rotate_num)
{
	Block_init();

	if(rotate_num%4==0)
	{
		setBlock(0,1,3);
		setBlock(1,1,3);
		setBlock(2,0,3);
		setBlock(2,1,3);
	}
	else if(rotate_num%4==1)
	{
		setBlock(1,0,3);
		setBlock(1,1,3);
		setBlock(1,2,3);
		setBlock(2,2,3);
	}
	else if(rotate_num%4==2)
	{
		setBlock(0,1,3);
		setBlock(0,2,3);
		setBlock(1,1,3);
		setBlock(2,1,3);
	}
	else
	{
		setBlock(0,0,3);
		setBlock(1,0,3);
		setBlock(1,1,3);
		setBlock(1,2,3);
	}
}
