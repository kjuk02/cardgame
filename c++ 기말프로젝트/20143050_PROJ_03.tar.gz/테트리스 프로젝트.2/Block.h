#ifndef TETROMINO
#define TETROMINO

class Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	Block();
	void Block_init();
	void setBlock(int x,int y,int value);
	int get_shape(const int x,const int y);
	virtual void rotate_block(int rotate_num);
	~Block();
};
#endif
