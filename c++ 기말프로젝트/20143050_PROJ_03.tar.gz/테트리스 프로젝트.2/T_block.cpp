#include"T_block.h"

T_block::T_block() : Block()
{
	Block_init();
	setBlock(0,1,6);
	setBlock(1,0,6);
	setBlock(1,1,6);
	setBlock(1,2,6);
}
T_block::~T_block(){};

void T_block::rotate_block(int rotate_num)
{
	Block_init();

	if(rotate_num%4==0)
	{
		setBlock(0,1,6);
		setBlock(1,0,6);
		setBlock(1,1,6);
		setBlock(1,2,6);
	}
	else if(rotate_num%4==1)
	{
		setBlock(0,1,6);
		setBlock(1,0,6);
		setBlock(1,1,6);
		setBlock(2,1,6);
	}
	else if(rotate_num%4==2)
	{
		setBlock(1,0,6);
		setBlock(1,1,6);
		setBlock(1,2,6);
		setBlock(2,1,6);
	}
	else
	{
		setBlock(0,1,6);
		setBlock(1,1,6);
		setBlock(1,2,6);
		setBlock(2,1,6);
	}
}
