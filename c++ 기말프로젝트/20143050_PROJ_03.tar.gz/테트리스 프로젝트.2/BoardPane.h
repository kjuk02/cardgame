#include"Pane.h"
#include"Block.h"
class BoardPane : public Pane {
public:
BoardPane(int x, int y, int w, int h);
void draw();
void draw2(int x,int y,int board[20][10],Block* block_);
};
