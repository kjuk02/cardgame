#include"NextPane.h"

NextPane::NextPane(int x, int y, int w, int h) : Pane(x,y,w,h){}

void NextPane::draw(){
  init_pair(1, COLOR_BLUE, COLOR_BLACK);
  wattron(win_, COLOR_PAIR(1));
  for (int i=0; i<height_; i++)
  mvwhline(win_, i, 0, ACS_CKBOARD, width_);
  mvwprintw(win_, 0,0, "NEXT PANE");
  wattroff(win_, COLOR_PAIR(1));
  wrefresh(win_);
}

void NextPane::draw2(int x,int y,Block* temp_block)
{
  init_pair(1, COLOR_BLUE, COLOR_BLACK);
  init_pair(50,COLOR_YELLOW,COLOR_YELLOW);
  init_pair(51,COLOR_BLUE,COLOR_BLUE);
  init_pair(52,COLOR_GREEN,COLOR_GREEN);
  init_pair(53,COLOR_MAGENTA,COLOR_MAGENTA);
  init_pair(54,COLOR_RED,COLOR_RED);
  init_pair(55,COLOR_CYAN,COLOR_CYAN);
  init_pair(56,COLOR_WHITE,COLOR_WHITE);

  temp_block->rotate_block(0);
  wattron(win_, COLOR_PAIR(1));
  for (int i=0; i<height_; i++)
  mvwhline(win_, i, 0, ACS_CKBOARD, width_);
  mvwprintw(win_, 0,0, "NEXT PANE");
  wattroff(win_, COLOR_PAIR(1));
  wrefresh(win_);

  	for(int i = 0; i < 4; i++)
  	{
  		for(int j = 0; j <4; j++)
  		{
  			if(temp_block -> get_shape(i,j) != 0)
  			{
  				wattron(win_,COLOR_PAIR(temp_block->get_shape(i,j)+49));
  				mvwprintw(win_, x+i+1,(y+j)*2 +1,"  ");
  				wattroff(win_,COLOR_PAIR(temp_block->get_shape(i,j)+49));
  			}
  		}
  	}
  	wrefresh(win_);
}
