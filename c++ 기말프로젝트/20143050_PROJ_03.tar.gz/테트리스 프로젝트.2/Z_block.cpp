#include"Z_block.h"

Z_block::Z_block() : Block()
{
	Block_init();
	setBlock(0,1,5);
	setBlock(1,0,5);
	setBlock(1,1,5);
	setBlock(2,0,5);
}
Z_block::~Z_block(){};

void Z_block::rotate_block(int rotate_num)
{
	Block_init();

	if(rotate_num%2==0)
	{
		setBlock(0,1,5);
		setBlock(1,0,5);
		setBlock(1,1,5);
		setBlock(2,0,5);
	}
	else
	{
		setBlock(0,0,5);
		setBlock(0,1,5);
		setBlock(1,1,5);
		setBlock(1,2,5);
	}
}
