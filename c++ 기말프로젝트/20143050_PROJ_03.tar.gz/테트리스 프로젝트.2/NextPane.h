#include"Pane.h"
#include"Block.h"

class NextPane : public Pane {
public:
NextPane(int x, int y, int w, int h);
void draw();
void draw2(int x,int y,Block* tmep_block);
};
