#ifndef I_bLOCK
#define I_bLOCK
#include"Block.h"
class I_block : public Block
{
private:
	static const int width = 4;
	int board[width][width];
public:
	I_block();
	virtual void rotate_block(int rotate_num);
	~I_block();
};
#endif
