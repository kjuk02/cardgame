#include"BoardPane.h"
#include<iostream>
#include<string>

class block:public BoardPane{
public:
block(int x,int y, int w, int h);
void draw();
};
