#include"block.h"
#include"Pane.h"
#include"InfoPane.h"
#include"BoardPane.h"
#include"StatPane.h"
#include"HelpPane.h"
#include"NextPane.h"
#include<fstream>

class Tetris {
Pane *infoPane_, *helpPane_, *nextPane_, *boardPane_, *statPane_,*block_;
public:
Tetris();
~Tetris();
void play();
void updateScreen();
void hw();
void hw1_(char ch,std::ifstream& instream);
void hw2(int arr[][19]);
void hw3(int arr[][19],int arr2[],int &value);
};
