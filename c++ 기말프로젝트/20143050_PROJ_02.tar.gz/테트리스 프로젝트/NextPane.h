#include"Pane.h"

class NextPane : public Pane {
public:
NextPane(int x, int y, int w, int h);
void draw();
};
