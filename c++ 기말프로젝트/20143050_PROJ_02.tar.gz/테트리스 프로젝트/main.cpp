#include"Tetris.h"

int main(){
Tetris t;
t.play();
std::ifstream instream;
instream.open("input.txt");
char ch;
instream>>ch;
if (ch==NULL)
{
  t.hw();
}
else
{
  t.hw1_(ch,instream);
}
return 0;
}
