#include"block.h"

block::block(int x, int y, int w, int h) : BoardPane(x,y,w,h){}

void block::draw(){
  init_pair(66, COLOR_RED, COLOR_GREEN);
  wattron(win_, COLOR_PAIR(66));
  mvwhline(win_, 0, 0, ACS_CKBOARD, 4);
  mvwhline(win_, 1, 0, ACS_CKBOARD, 4);
  wattroff(win_, COLOR_PAIR(66));
  wrefresh(win_);
}
