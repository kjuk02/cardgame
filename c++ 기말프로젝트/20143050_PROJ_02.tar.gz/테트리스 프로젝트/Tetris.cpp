#include"Tetris.h"

Tetris::Tetris(){
initscr();
start_color();
cbreak();
refresh();
infoPane_ = new InfoPane(1,1,25,5);
helpPane_ = new HelpPane(1,6,25,12);
nextPane_ = new NextPane(1,18,25,5);
statPane_ = new StatPane(60,3,20,20);
boardPane_ = new BoardPane(30,0,22,22);
block_=new block(39,1,4,2);
}
void Tetris::hw3(int arr[][19],int arr2[],int &value)
{
  int count=0;
  int mino=0;
  int row=0;
  for(int i=0;i<19;i++)
  {
      count=0;
      for(int j=0;j<19;j++)
        if(arr[i][j]==1)
          count++;
      if(count==5)
      {
        boardPane_->draw();
        for(int j=0;j<19;j++)
        {
          arr[i][j]=0;
        }
        row=i;
        mino=1;
        value+=2;
      }
  }
  if(mino==1)
  {
    for(int i=row;i>=0;i--)
     for(int j=18;j>=0;j--)
       if(arr[i][j]==1)
       {
        arr[i][j]=0;
        arr[i+2][j]=1;
       }
      for(int j=0;j<19;j++)
      {
        if(arr2[j]>=18)
         arr2[j]=18;
       else
       arr2[j]+=2;
     }
  }
}
void Tetris::hw2(int arr[][19]){
  for(int i=0;i<19;i++)
    for(int j=0;j<19;j++)
      if(arr[i][j]==1)
      {
        block_=new block(31+j,1+i,4,2);
        block_->draw();
      }
}

void Tetris::hw(){
  int down=0;
  int value=0;
  int position=8;
  int arr[19][19]={{0,0}};
  int arr2[19]={18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18};
  block_->draw();

  while(1)
  {
    int ch2;
    int ch;
    raw();                          /* Line buffering disabled      */
    keypad(stdscr, TRUE);           /* We get F1, F2 etc..          */
    noecho();                       /* Don't echo() while we do getch */

    ch2 = getch();                   /* If raw() hadn't been called*/
    ch= ch2;
  if(ch==KEY_DOWN)
  {
    down+=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch==KEY_LEFT)
  {
    position-=2;
    if(position<0)
    position+=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch==KEY_RIGHT)
  {
    position+=2;
    if(position>16)
    position-=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch=='q')
  break;
  else if(ch=='d')
  {
    down=arr2[position];
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
 for(int i=0;i<18;i++)
 {
   if(down==arr2[i])
    {
        if(position==i&&i!=0&&i!=16)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          arr2[i]-=2;
          if(arr[i]!=arr[i-2])
          arr2[i-2]=arr2[i];
          if(arr[i]!=arr[i+2])
          arr2[i+2]=arr2[i];
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
        else if(position==i&&i==0)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          if(arr2[i+2]==arr2[i])
          arr2[i+2]-=2;
          arr2[i]-=2;
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
        else if(position==i&&i==16)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          if(arr2[i-2]==arr2[i])
          arr2[i-2]-=2;
          arr2[i]-=2;
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
    }
  }
  }
}
void Tetris::hw1_(char ch,std::ifstream& instream){
  int down=0;
  int value=0;
  int position=8;
  int arr[19][19]={{0,0}};
  int arr2[19]={18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18};
  block_->draw();

  while(1)
  {
    if(ch=='g')
  {
    down+=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch=='l')
  {
    position-=2;
    if(position<0)
    position+=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch=='r')
  {
    position+=2;
    if(position>16)
    position-=2;
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
  else if(ch=='d')
  {
    down=arr2[position];
    boardPane_->draw();
    hw2(arr);
    block_=new block(31+position,1+down,4,2);
    block_->draw();
  }
 for(int i=0;i<18;i++)
 {
   if(down==arr2[i])
    {
        if(position==i&&i!=0&&i!=16)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          arr2[i]-=2;
          if(arr[i]!=arr[i-2])
          arr2[i-2]=arr2[i];
          if(arr[i]!=arr[i+2])
          arr2[i+2]=arr2[i];
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
        else if(position==i&&i==0)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          if(arr2[i+2]==arr2[i])
          arr2[i+2]-=2;
          arr2[i]-=2;
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
        else if(position==i&&i==16)
        {
          arr[down][position]=1;
          down=0;
          position=8;
          if(arr2[i-2]==arr2[i])
          arr2[i-2]-=2;
          arr2[i]-=2;
          hw3(arr,arr2,value);
          ((StatPane *)statPane_)->draw2(value);
          hw2(arr);
          block_=new block(39,1,4,2);
          block_->draw();
        }
    }
  }
  instream>>ch;
  }
}
Tetris::~Tetris()
{
delete infoPane_;
delete helpPane_;
delete nextPane_;
delete boardPane_;
delete statPane_;
delete block_;
endwin();
}

void Tetris::play(){
updateScreen();
}

void Tetris::updateScreen(){
infoPane_->draw();
helpPane_->draw();
nextPane_->draw();
statPane_->draw();
boardPane_->draw();
}
