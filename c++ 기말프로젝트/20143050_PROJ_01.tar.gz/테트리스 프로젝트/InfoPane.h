#include"Pane.h"
#include<ncurses.h>

class InfoPane : public Pane {
public:
InfoPane(int x, int y, int w, int h);
void draw();
};
