#include"Tetris.h"

int main(){
Tetris t;
t.play();
}
