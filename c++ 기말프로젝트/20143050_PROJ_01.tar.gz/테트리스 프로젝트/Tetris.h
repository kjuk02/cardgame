#include"Pane.h"
#include"InfoPane.h"
#include"BoardPane.h"
#include"StatPane.h"
#include"HelpPane.h"
#include"NextPane.h"

class Tetris {
Pane *infoPane_, *helpPane_, *nextPane_, *boardPane_, *statPane_;
public:
Tetris();
~Tetris();
void play();
void updateScreen();
};
